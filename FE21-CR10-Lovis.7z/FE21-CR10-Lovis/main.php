<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <?php include_once 'components/bootcss.php';?>
    <title>Document</title>
</head>
<body>
      <header>
            <?php
            include_once 'components/navi.php';

            ?>
        </header>
        <div class="d-flex justify-content-center align-items-center" style="background-image: url(https://www.gcpsk12.org/cms/lib/GA02204486/Centricity/Domain/5086/header-books-desktop-animated.gif); height: 50vh; background-size: cover; background-repeat: no-repeat; background-position: 60% 90%;">
        <h1 class="text-center text-light"><br><br><br>Get your Items now!</h1>
    </div>
    <div class="container">
        <div class="row justify-content-evenly py-2">
            <?php 
            include_once 'actions/db_connect.php';
            include_once 'actions/showitems.php';


            $query ="SELECT * FROM media LEFT JOIN author ON media.author_id = author.author_id";
            $result = mysqli_query ($connect, $query);
            for ($set = array (); $row = $result-> fetch_assoc(); $set [] = $row);


            foreach($set as $value)
            {


                $image = ' ';
                if(strlen($value ['image'] ) < 20  )
                {
                    $image = 'pictures/'.$value ['image'];
                } else
                $image =  $value ['image'];
                echo showItem ($image, $value['title'], $value['type'], $value['f_name'].' '.$value['l_name'], $value['id'], $value['author_id']);




                }
                ?>
            </div>
        </div>
        <?php
            include_once 'components/footer.php';
            ?>

        <?php include_once 'components/bootjs.php';?>
            </body>
            </html>