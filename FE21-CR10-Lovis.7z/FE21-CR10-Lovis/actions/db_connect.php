<?php
$hostname = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "fswd13_CR10_Lovis_BigLibrary" ;
            
$connect = new mysqli($hostname, $username, $password, $dbname);
            
if(mysqli_connect_error()) {
    die("Connection failed");
}