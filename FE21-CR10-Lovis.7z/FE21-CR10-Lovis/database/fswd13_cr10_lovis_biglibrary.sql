-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 14. Aug 2021 um 20:50
-- Server-Version: 10.4.20-MariaDB
-- PHP-Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `fswd13_cr10_lovis_biglibrary`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `author`
--

CREATE TABLE `author` (
  `author_id` int(11) NOT NULL,
  `f_name` varchar(25) NOT NULL,
  `l_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `author`
--

INSERT INTO `author` (`author_id`, `f_name`, `l_name`) VALUES
(1, 'One', 'Murata'),
(2, 'Jayne', 'Austin'),
(3, 'Martin', 'Ritter'),
(4, 'Bill', 'Waterson'),
(5, 'Some', 'Lady'),
(6, 'Kurt', 'Kokos'),
(7, 'Akira', 'Kurosawa'),
(8, 'Viggo', 'Mortenhorse'),
(9, 'Question', 'Tarantula'),
(10, 'Dalt', 'Wisney');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `media`
--

CREATE TABLE `media` (
  `id` int(11) NOT NULL,
  `image` varchar(300) NOT NULL,
  `author_id` int(11) NOT NULL,
  `ISBN` varchar(13) NOT NULL,
  `short_desc` varchar(300) NOT NULL,
  `publish_date` date NOT NULL,
  `publisher_id` int(11) NOT NULL,
  `type` varchar(13) NOT NULL,
  `status` enum('available','reserved') NOT NULL,
  `title` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `media`
--

INSERT INTO `media` (`id`, `image`, `author_id`, `ISBN`, `short_desc`, `publish_date`, `publisher_id`, `type`, `status`, `title`) VALUES
(1, 'Book1.jpg', 1, '978-4-08-8707', 'Nani?', '2012-06-14', 1, 'Book', 'reserved', 'One Punch Man Vol.1'),
(2, 'Boo2.jpg', 2, '9780141439518', 'Something about Men, I guess', '1813-01-28', 2, 'Book', 'available', 'Pride and Prejudice'),
(3, 'book3.jpg', 3, '978-134947092', 'Understand your Dog', '2015-12-08', 3, 'Book', 'available', 'Mensch-Hund, Hund-Mensch'),
(4, 'book4.jpg', 4, '978-144943325', 'Never mess with a 6 year old', '1985-11-18', 4, 'Book', 'available', 'Calvin&Hobbes Vol.2'),
(5, 'book5.jpg', 5, '978-344247895', 'It is lame, very much so', '2011-06-11', 5, 'Book', 'reserved', '50 Lames of Grey'),
(6, 'CD1.jpg', 6, '978-123477788', 'Smells like Copyright Infringement', '1991-09-11', 6, 'CD', 'available', 'Nerdvana'),
(7, 'dvd1.jpg', 7, '978-344247345', 'Omae wa mou shindeiru', '1954-04-11', 7, 'DVD', 'reserved', '7 Samurai'),
(8, 'dvd2.jpg', 8, '978-344234425', 'He loves his Horse', '2004-03-05', 8, 'DVD', 'available', 'Hidalgo'),
(17, 'dvd3.jpg', 9, '978-344281995', 'Thats a good Burger!', '1994-04-14', 9, 'DVD', 'reserved', 'PULP FICTION'),
(18, 'dvd4.jpg', 10, '978-231447895', 'The Hunted becomes the Hunter!', '1942-08-22', 10, 'DVD', 'available', 'BAMBO'),
(19, 'book6.jpg', 1, '978-344123455', 'Psychic kid wants to grow muscles', '2012-12-23', 1, 'Book', 'available', 'Mob Psycho 100 Vol. 14'),
(20, 'book4.jpg', 4, '978-341347845', 'More of the Kid and his tiger', '1986-07-12', 4, 'Book', 'available', 'Calvin&Hobbes Vol.4');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `publisher`
--

CREATE TABLE `publisher` (
  `publisher_id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `address` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `publisher`
--

INSERT INTO `publisher` (`publisher_id`, `name`, `address`) VALUES
(1, 'Kazé Manga', ' Av. de Provence 4 1007 Lausanne, Switze'),
(2, 'Penguin', 'Gütersloh, Germany'),
(3, 'Langenscheidt', 'Munich, Germany'),
(4, 'Carlsen', 'Hamburg, Germany'),
(5, 'Serious Books', '13 Whimsy Street, London'),
(6, 'Rainy Records', 'Tokio, Japan'),
(7, 'trigun-film', 'Ennetbaden, Switzerland'),
(8, '30th Century Horse', '413 Century Road, Century City,Californi'),
(9, 'Ducks Gate Entertainment', 'Santa Monica, Vereinigte Staaten'),
(10, 'Dalt Wisney Studios', 'Burbank, California,');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `author`
--
ALTER TABLE `author`
  ADD PRIMARY KEY (`author_id`);

--
-- Indizes für die Tabelle `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`id`),
  ADD KEY `publisher_id` (`publisher_id`),
  ADD KEY `author_id` (`author_id`);

--
-- Indizes für die Tabelle `publisher`
--
ALTER TABLE `publisher`
  ADD PRIMARY KEY (`publisher_id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `author`
--
ALTER TABLE `author`
  MODIFY `author_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT für Tabelle `media`
--
ALTER TABLE `media`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT für Tabelle `publisher`
--
ALTER TABLE `publisher`
  MODIFY `publisher_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `media`
--
ALTER TABLE `media`
  ADD CONSTRAINT `media_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `author` (`author_id`),
  ADD CONSTRAINT `media_ibfk_2` FOREIGN KEY (`publisher_id`) REFERENCES `publisher` (`publisher_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
