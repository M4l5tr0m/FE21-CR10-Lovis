<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php include_once 'components/bootcss.php';?>
    <title> Error x__X </title>
    <body>
         <header>
              <?php
                   include_once 'components/navi.php';

                   ?>
            </header>
            <div class="d-flex justify-content-center align-items-center" style="background-image: url(https://i.gifer.com/QedF.gif); height: 50vh; background-size: cover; background-repeat: no-repeat; background-position: 50% 30%;">
        <h1 class="text-center text-light">Nooooooooooooooooooooooooooooooooooo..........</h1>
    </div>
    <div class="container">
        <div class="mt-3 mb-3">
            <h1>Invalid Request</h1>
        </div>
        <div class="alert alert-warning" role="alert">
            <p> Incorrect. Please <a href="main.php" class="alert-link">go back</a> and retry.</p>
        </div>
    </div>
    <?php
        include_once 'components/footer.php';
    ?>
<?php include_once 'components/bootjs.php';?>
</body>
</html>